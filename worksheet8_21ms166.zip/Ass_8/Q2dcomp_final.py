import numpy as np
import matplotlib.pyplot as plt
#solving the sinusoidal BC problem using Crank-Nicolson algorithm
L = 1.0
N = 1000

a = 1
w = 25

xs,h  = np.linspace(0,L,N,retstep=True)
us = np.where(xs<L/2,2*xs,2-2*xs)
bdry = np.zeros(N-2)
bdry[0] = us[0]
bd=np.zeros(N-2)
bd[0]=us[0]
dt = .0005

mu = dt/(2*(h**2))

t = 0
tf = 10.0

line = plt.plot(xs,us)[0]
#plt.ylim(-.5,1.1)

A = np.eye(N-2)*(1.+ 2*mu) + np.eye(N-2,k=1)*(-mu) +np.eye(N-2,k=-1)*(-mu) #Defining matrix1 on LHS(at time(n+1))
A2= np.eye(N-2)*(1.- 2*mu) +  np.eye(N-2,k=1)*mu +np.eye(N-2,k=-1)*mu # Defining the matrix2 on RHS(time n)
B = np.linalg.inv(A)

while t<tf:
    us[-1]=np.sin(w*(t+dt))*np.sin(w*(t+dt))     #Defining the boundary term
    bdry[-1] =us[-1] 
    u1=np.sin(w*t)*np.sin(w*t) 
    bd[-1] =u1 
    us [1:-1] = np.dot(B,np.dot(A2,us[1:-1])+mu*(bd+bdry)) #Implementing the algorithm
    t += dt
    line.set_ydata(us)
    plt.pause(.000000001)
    


plt.show()
