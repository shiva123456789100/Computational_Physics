import numpy as np
import matplotlib.pyplot as plt
#Rod's both end has a fixed temperature=0_With Implicit method
L = 1.0 #Length of the Rod
N = 1000 #No of Lattice Point

w = 5.0

xs,h  = np.linspace(0,L,N,retstep=True)  
us = np.where(xs<L/2,2*xs,2-2*xs)
bdry = np.zeros(N-2)
bdry[0] = us[0]

dt = .001

mu = dt/h**2

t = 0
tf = 10.0

line, = plt.plot(xs,us)
plt.ylim(-.5,1.1)

A = np.eye(N-2)*(1.+2*mu) -mu* np.eye(N-2,k=1) -mu*np.eye(N-2,k=-1)  #Defining the matrix in Implicit method
B = np.linalg.inv(A) #Inverting the matrix

while t<tf:
    bdry[-1] = mu*us[-1] #Defining Boundary term
    us [1:-1] = np.dot(B,us[1:-1]+bdry) #Code for solving simultaneous linear  equation
    t += dt
    line.set_ydata(us)
    plt.pause(.0001)

plt.show()
