import numpy as np
import matplotlib.pyplot as plt
#Solving the the heat equation of unit length rod with two end at 0 using Crank-Nicolson algorithm
L = 1.0 #Length
N = 1000

w = 25.0

xs,h  = np.linspace(0,L,N,retstep=True)
us = np.where(xs<L/2,2*xs,2-2*xs)
bdry = np.zeros(N-2)
bdry[0] = us[0]

dt = .0001

mu = dt/h**2

t = 0
tf = 10.0

line, = plt.plot(xs,us)
plt.ylim(-.5,1.1)

A = np.eye(N-2)*(1.+mu) - (mu/2)* np.eye(N-2,k=1) -(mu/2)*np.eye(N-2,k=-1) #Defining the Matrix 
B = np.linalg.inv(A) #Inverting matrix

while t<tf:
    bdry[-1] = mu*us[-1] #Defining the boundary condition
    us [1:-1] = np.dot(B,(1-mu)*us[1:-1]+bdry+(mu/2)*us[:-2]+(mu/2)*us[2:]) #Solving the linear equation
    t += dt
    line.set_ydata(us)
    plt.pause(.0001)

plt.show()
