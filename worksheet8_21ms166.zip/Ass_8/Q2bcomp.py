import numpy as np
import matplotlib.pyplot as plt

L = 1.0 #Length
N = 1000 #No of Lattice

a = 1
w = 25

xs,h  = np.linspace(0,L,N,retstep=True)
us = np.where(xs<L/2,2*xs,2-2*xs)
bdry = np.zeros(N-2)
bdry[0] = us[0]

dt = .001

mu = dt/h**2

t = 0
tf = 10.0

line, = plt.plot(xs,us)
plt.ylim(-.5,1.1)

A = np.eye(N-2)*(1.+2*mu) -mu* np.eye(N-2,k=1) -mu*np.eye(N-2,k=-1) #Writing the matrix
B = np.linalg.inv(A) #Inverting the matrix

while t<tf:
    us[-1] = a*(np.sin(w*t))**2 #Imposing the Booundary Condition
    bdry[-1] = mu*us[-1] #Defining the boundary term
    us [1:-1] = np.dot(B,us[1:-1]+bdry) #Solving the Simultaneous linear eq
    t += dt
    line.set_ydata(us)
    plt.pause(.0001)

plt.show()
