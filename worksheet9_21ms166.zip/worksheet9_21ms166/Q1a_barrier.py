import numpy as np
import matplotlib.pyplot as plt
# Grid points# Grid points
N = 201
# Create the grid
xs, h = np.linspace(-10.0,10.0,N,retstep=True)
# Timestep
delt = 0.01
# Given potentialimport numpy as np
import matplotlib.pyplot as plt
U = np.zeros(N)
U=np.where(abs(xs-6.0)<1,40.0,0)
# Initial condition
s=0.2
x=3*np.ones(len(xs))
phi0 = np.exp(-(xs-x)**2/(2*(s**2)))/(np.sqrt(2*np.pi)*s)
# Boundary condition
#p0 = 0.0
#p1 = 0.0
# A parameter used in expressions
k = 2.0j/delt
# Construct A matrix
A = (k*np.eye(N) - np.diag(U))*h**2 - 2*np.eye(N) + np.eye(N,k=1) + np.eye(N,k=-1)
# Calculate the inverse
Ainv = np.linalg.inv(A)
# Calculate the propagatorimport numpy as np
import matplotlib.pyplot as plt
Uprop = Ainv*(4*1j*h**2)/delt - np.eye(N)

phi = phi0
# set initial and final times
t = 0.0
tfinal = 6.0
# k keeps track of iterations
k = 0
plt.plot(xs, U,linestyle="dashed")
plt.xlabel("Position")
plt.title("Potential")
line = plt.plot(xs,np.real(phi))[0]
dye= plt.plot(xs,np.abs(phi)*np.abs(phi))[0]#Probability density
plt.ylim([-1,1])
while t<tfinal:
       # Evolve
        phi = np.dot(Uprop,phi)
        # Increment t
        t += delt
        # plot after every 40 iteration
        line.set_ydata(np.real(phi))
        dye.set_ydata(np.abs(phi)*np.abs(phi)) 
        plt.pause(0.001)
       # increment k
        k += 1
plt.show()
